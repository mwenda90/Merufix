package com.mongodb.app.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFF7A44E4)
val Purple500 = Color(0xFF5824E4)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)
val Blue = Color(0xFF387CAC)
